package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Personagem> inimigos = new ArrayList<>();
        inimigos.add(new Personagem("orc", 100, 10));
        inimigos.add(new Personagem("goblin", 50, 5));
        inimigos.add(new Personagem("lobo", 75, 15));
        inimigos.add(new Personagem("cavaleiro", 200, 20));
        inimigos.add(new Personagem("dragão", 500, 50));
        Personagem jogador = new Personagem("steve", 220, 20);

        Random random = new Random();

        while (jogador.estaVivo() && inimigos.stream().anyMatch(Personagem::estaVivo)) {
           List<Personagem> vivos = inimigos.stream().filter(Personagem::estaVivo).toList();
           Personagem alvo = vivos.get(random.nextInt(vivos.size()));
           jogador.atacar(alvo);


            for (Personagem inim : inimigos) {
                     if (!jogador.estaVivo()) break;
                     if (inim.estaVivo()){
                         inim.atacar(jogador);
                }
            }
            System.out.println("------fim do turno----------");
        }
        if(jogador.estaVivo()){
            System.out.println("Steve venceu!");
        }else{
            System.out.println("steve perdeu!");
        }

    }
}



